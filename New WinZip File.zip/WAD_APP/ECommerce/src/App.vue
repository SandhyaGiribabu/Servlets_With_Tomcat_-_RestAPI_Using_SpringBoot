<template>
  <div id="app">
    <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/register">Register</router-link> |
      <router-link to="/login">Login</router-link> |
      <router-link to="/cart">Cart</router-link> |
      <router-link to="/logout">Logout</router-link>
    </nav>
    <router-view/>
  </div>
</template>

<script>
export default {
  name: "App"
}
</script>

<style>
nav {
  background-color: #eee;
  padding: 10px;
}
nav a {
  margin-right: 10px;
  text-decoration: none;
  color: #333;
}
</style>
