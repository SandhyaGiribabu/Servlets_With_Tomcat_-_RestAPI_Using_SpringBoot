import { createRouter, createWebHistory } from 'vue-router'
import RegisterPage from '../components/RegisterPage.vue'
import LoginPage from '../components/LoginPage.vue'
import ShowItems from '../components/ShopItems.vue'
import AddCart from '../components/AddCart.vue'
import LogoutPage from '../components/LogoutPage.vue'

const routes = [
  { path: '/', name: 'ShowItems', component: ShowItems },
  { path: '/register', name: 'Register', component: RegisterPage },
  { path: '/login', name: 'Login', component: LoginPage },
  { path: '/cart', name: 'Cart', component: AddCart },
  { path: '/logout', name: 'Logout', component: LogoutPage },
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
