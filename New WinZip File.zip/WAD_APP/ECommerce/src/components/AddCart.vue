<template>
  <h1>Cart Page</h1>
  <h2>Items Count: {{ cart_count }}</h2>
  <h2>Total Amount: {{ total_amount }}$</h2>
  <div id="div_item">
    <div v-for="item in cart_items" :key="item.id" id="item">
      <h3>{{ item.title }}</h3>
      <img :src="item.image" :alt="item.title" id="image">
      <p>Price: {{ item.price * item.quantity }}$</p>
      <div id="quantity">
        <button @click="increment(item)">+</button>
        <p>{{ item.quantity }}</p>
        <button @click="decrement(item)">-</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'

let cart_items = ref([])
let cart_count = ref(0)

const total_amount = computed(() => {
  return cart_items.value.reduce((sum, item) => sum + item.price * item.quantity, 0)
})

onMounted(() => {
  const items = localStorage.getItem('cart_items')
  const count = localStorage.getItem('cart_count')
  if (items) {
    cart_items.value = JSON.parse(items).map(i => ({ ...i, quantity: 1 }))
  }
  if (count) {
    cart_count.value = Number(count)
  }
})

const increment = (item) => {
  item.quantity++
  cart_count.value++
}

const decrement = (item) => {
  item.quantity--
  cart_count.value--
  if (item.quantity < 1) {
    const index = cart_items.value.indexOf(item)
    cart_items.value.splice(index, 1)
    cart_count.value = cart_items.value.length
    localStorage.setItem('cart_count', cart_count.value)
    localStorage.setItem('cart_items', JSON.stringify(cart_items.value))
  }
}
</script>

<style scoped>
#item {
  width: 400px;
  height: 300px;
  border: 1px solid #ddd;
  border-radius: 10px;
  padding: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  text-align: center;
  background-color: #fafafa;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

#div_item {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}

#image {
  width: 100px;
  height: 100px;
}

#quantity {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10px;
}
</style>
