<template>
  <div class="login-container">
    <h1>Login</h1>
    <form @submit.prevent="handleSubmit">
      <label>Email:</label>
      <input type="email" v-model="email" placeholder="Enter your email" required /><br/>

      <label>Password:</label>
      <input type="password" v-model="password" placeholder="Enter your password" required /><br/>

      <button type="submit">Login</button>
    </form>

    <p v-if="responseMsg" class="response-msg">{{ responseMsg }}</p>
    <p>Not registered? <router-link to="/register">Click Register</router-link></p>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

// Form fields
const email = ref('')
const password = ref('')
const responseMsg = ref('')

async function handleSubmit() {
  try {
    const res = await fetch('/api/users_register/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: email.value,
        password: password.value
      })
    })

    if (!res.ok) throw new Error('Invalid credentials or server error')

    const data = await res.json()
    responseMsg.value = 'Login Successful! Redirecting to Shop...'

    setTimeout(() => {
      router.push('/')
    }, 1500)

    console.log('Response:', data)
  } catch (err) {
    responseMsg.value = 'Login failed: ' + err.message
  }
}
</script>

<style scoped>
.login-container {
  max-width: 400px;
  margin: 50px auto;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  background-color: #f9f9f9;
  text-align: center;
}

label {
  display: block;
  margin: 10px 0 5px;
  font-weight: bold;
  text-align: left;
}

input {
  width: 100%;
  padding: 8px;
  margin-bottom: 10px;
  border-radius: 6px;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  padding: 10px 20px;
  background-color: #2196F3;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
}

button:hover {
  background-color: #1976D2;
}

.response-msg {
  margin-top: 10px;
  font-weight: bold;
  color: green;
}
</style>
