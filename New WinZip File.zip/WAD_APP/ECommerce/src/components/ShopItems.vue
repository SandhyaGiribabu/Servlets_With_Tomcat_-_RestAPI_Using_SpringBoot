<template>
  <div id="div1">
    <h1>Shopped Items Count: {{ a_items_count }}</h1>
    <button @click="addToCart">Go to Cart</button>
  </div>
  <div id="div_item">
    <div v-for="item in items" :key="item.id" id="item">
      <h3>{{ item.title }}</h3>
      <img :src="item.image" :alt="item.title" id="image">
      <p>Price: {{ item.price }}$</p>
      <button @click="add_item({ title: item.title, price: item.price, image: item.image })">
        Select Item
      </button>
    </div>
  </div>
</template>

<script setup async>
import { useRouter } from 'vue-router'
import { onMounted, ref } from 'vue'

const router = useRouter()
let items = ref([])
var a_items = ref([])
var a_items_count = ref(0)

onMounted(async () => {
  if (items.value.length === 0) { // safe guard
    const res = await fetch('https://fakestoreapi.com/products')
    items.value = await res.json()
  }
})

const add_item = (item) => {
  a_items.value.push(item)
  a_items_count.value = a_items.value.length
}

const addToCart = () => {
  localStorage.setItem('cart_items', JSON.stringify(a_items.value))
  localStorage.setItem('cart_count', a_items_count.value)
  router.push('/cart')
}
</script>

<style scoped>
#item {
  width: 200px;
  height: 300px;
  border: 1px solid #ddd;
  border-radius: 10px;
  padding: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  text-align: center;
  background-color: #fafafa;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

#div_item {
  display: flex;
  flex-wrap: wrap;
  /*  */
  justify-content: space-around;
}

#image {
  width: 100px;
  height: 100px;
}

#div1 {
  text-align: right;
  margin: 10px;
}
</style>
