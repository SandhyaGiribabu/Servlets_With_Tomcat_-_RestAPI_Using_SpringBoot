<template>
  <div>
    <h2>Logout</h2>
    <p>You have been logged out.</p>
  </div>
</template>

<script>
export default {
  name: "LogoutPage"
}
</script>
