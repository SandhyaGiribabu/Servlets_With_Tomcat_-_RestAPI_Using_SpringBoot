<template>
  
  <div>
    <div v-for="item in items" :key="item.id">
        <h2>hiii</h2>
        <h2>{{ item.name }}</h2>
        <button @click = "addtocart(item)">add</button>

    </div>
    <form @submit.prevent="submit">
        <input v-model="name"></input>
    </form>
    
  </div>
</template>

<script setup>
    import {ref,onMounted} from 'vue'

    const items = ref([])
    const name = ref('')
    items.value = [{id:1,name:'product1'}]
    const addtocart = (item) =>{
        items.value.push(item)
    };
    const submit = () => {items.value.push({id:1,name:'product1'})}

    localStorage.setItem('cart',JSON.stringify(items.value))
    const res =  localStorage.getItem('cart')
    const n = ref([])
    n.value = JSON.parse(res).map(i=>({...i,quantity:1}))
    console.log(n.value)
   
</script>