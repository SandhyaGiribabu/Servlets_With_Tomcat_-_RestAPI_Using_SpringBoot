
<template>
  <div>
    <router-link to="/home">Home</router-link>
    <router-link to="/cart">Cart</router-link>
    <router-view></router-view>
  </div>

</template>

<style scoped>

</style>
